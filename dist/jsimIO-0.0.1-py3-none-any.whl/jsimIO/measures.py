class Measure:
    SystemThroughput = "System Throughput"
